﻿namespace WebApiAjax
{
    public class CalcResult
    {
        public int Sum { get; set; }
        public int Difference { get; set; }
        public int Product { get; set; }
        public int Quotient { get; set; }
    }

}
